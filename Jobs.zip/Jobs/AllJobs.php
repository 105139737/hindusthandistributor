<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require("../config.php");


$data1= mysqli_query($conn,"select * from  main_aa_jobs where status!='Done'")or die(mysqli_error($conn));
while ($row1 = mysqli_fetch_array($data1))
{
$id=$row1['id'];
$link=$row1['link'].'&file_name='.$id;
$query1 = "UPDATE main_aa_jobs Set status='Processing' where id='$id'";
$result1 = mysqli_query($conn,$query1);

$opts = array('http' =>
    array(
        'method'  => 'GET',
        'header'  => 'Content-type: application/x-www-form-urlencoded',
        'content' => $id
    )
);
$context  = stream_context_create($opts);
$filename = file_get_contents($link, false, $context);
$filename="Jobs/Jobs_Report/".$id.".xls";
date_default_timezone_set('Asia/Kolkata');
$comp_date=date('Y-m-d h:i:s');
$query = "UPDATE main_aa_jobs Set comp_date='$comp_date',status='Done',file='$filename' where id='$id'";
$result = mysqli_query($conn,$query);


die();
}
mysqli_close($conn);
